package ai.ds.testlayer;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assertsion {
	
	@Test
	public void test()
	{   SoftAssert softassert = new SoftAssert();   //create a object 
		System.out.println("open Browser and Hit URL ");  //facebbok
		softassert.assertEquals(false, true,"incorrect login url");
		System.out.println("enter Username");
		System.out.println("entr password");
		System.out.println("click on login button");
	
		System.out.println("Home Page Validation");
		softassert.assertEquals(true, false,"home page url not found ");  //aseertion fail 
		System.out.println("tab Page Validation");
		System.out.println("IMP CODE");
		softassert.assertAll();
		
	}
	
	

}
